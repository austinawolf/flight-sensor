from vscode_c_dev.main import main

main()

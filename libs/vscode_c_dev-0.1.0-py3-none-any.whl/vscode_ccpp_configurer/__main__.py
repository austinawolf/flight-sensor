from vscode_ccpp_configurer.main import main

main()

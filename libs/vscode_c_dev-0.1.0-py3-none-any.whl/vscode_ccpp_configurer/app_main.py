import json
import argparse
import os.path

parser = argparse.ArgumentParser(description='Configure VSCode Propertires File')
parser.add_argument('--path', dest='path',
                    help='')
parser.add_argument('--defines', dest='defines',
                    help='')
parser.add_argument('--define-prefix', dest='define_prefix', required=False,
                     help='')
parser.add_argument('--includes', dest='includes',
                    help='')


class Defines:
    @classmethod
    def from_args(cls, text, prefix):
        defines_raw_list = text.split(" ")
        defines = []
        for item in defines_raw_list:
            if item.startswith(prefix):
                defines.append(item[len(prefix):])
        return cls(defines)

    def __init__(self, items):
        self.items = items


class Includes:
    @classmethod
    def from_args(cls, text):
        include_raw_list = text.split(" ")
        includes = []
        for item in include_raw_list:
            absolute_path = os.path.abspath(item)
            includes.append(absolute_path)
        return cls(includes)

    def __init__(self, items):
        self.items = items


class CCppConfig:
    @classmethod
    def from_json(cls, path):
        with open(path) as json_file:
            info = json.load(json_file)
        return cls(path, info)

    def __init__(self, path, info):
        print(info)
        self._path = path
        self._info = info

    def insert_includes(self, includes):
        for c in self._info['configurations']:
            c['includePath'] = includes

    def insert_defines(self, defines):
        for c in self._info['configurations']:
            c['defines'] = defines

    def to_json(self):
        with open(self._path, "w") as json_file:
            json.dump(self._info, json_file, indent=4)


def main():
    args = parser.parse_args()

    path = args.path
    defines_raw = args.defines
    define_prefix = args.define_prefix if args.define_prefix else ""
    includes_raw = args.includes

    if path is None:
        raise Exception

    if defines_raw is None and includes_raw is None:
        raise Exception

    file_path = os.path.join(path, ".vscode", "c_cpp_properties.json")
    ccpp_config = CCppConfig.from_json(file_path)

    if defines_raw:
        defines = Defines.from_args(defines_raw, define_prefix)
        print(defines.items)
        ccpp_config.insert_defines(defines.items)

    if includes_raw:
        includes = Includes.from_args(includes_raw)
        print(includes.items)
        ccpp_config.insert_includes(includes.items)

    ccpp_config.to_json()


main()
